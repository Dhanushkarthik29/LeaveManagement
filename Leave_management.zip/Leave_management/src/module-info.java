/**
 * 
 */
/**
 * @author dhanushkrishna_k
 *
 */
module Leave_management {
	requires java.sql;
	requires json.simple;
	requires java.base;
	requires mysql.connector.j;
	requires java.mail;
}